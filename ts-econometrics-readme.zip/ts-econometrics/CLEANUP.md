# Tidy-up checklist for ts-econometrics

Do this before sending the repository link to anyone.

## Remove from the repository

| File | Why |
|---|---|
| `2312.02591v1.pdf` | The authors' paper — do not redistribute; the README links to arXiv instead |
| `.Rapp.history` | Local R console history, now covered by `.gitignore` |
| `graduation.tex` | Unrelated to this project — move it elsewhere |
| `gstfm_results_20260105_063820/`, `gstfm_saved_20260115_070311/` | Timestamped run folders; keep one, rename it `results/`, or drop both if the `.rds` files already cover the figures |

Removing a file from the working tree does not remove it from history. If that matters, either delete and
recreate the repository, or rewrite history with `git filter-repo`.

## Check

- `Seminar-paper.tex` — earlier versions contained working notes and an empty "Results" section. Either finish
  the text or keep only the compiled `paper.pdf` in the repository.
- Decide whether both `Report` and `Seminar-paper` need to be public, or whether one of them is enough.
- Add a repository description and topics on GitHub: `time-series`, `factor-models`, `spatial-statistics`, `r`.

## Suggested structure

```
README.md
LICENSE
.gitignore
code.Rmd              # the replication
Report.Rmd / .pdf     # write-up
paper.pdf             # seminar paper
references.bib
results/              # cached .rds and figures
```
